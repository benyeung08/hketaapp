# APP 1933 彩虹版 - 網站 + APK 同一個 ZIP (GitHub 一鍵解壓版)

呢個 ZIP 就係你要求嘅 **網站與 APK 一起打包成同一個 ZIP 並可以用 GitHub 解壓** 嘅終極版。

## 📦 點樣用 GitHub 解壓？

### 方法 1: 直接推上 GitHub (最簡單，推薦)
1. 下載呢個 ZIP
2. 解壓到電腦
3. 將解壓後嘅所有檔案推上你 GitHub Repo `main` 分支
   ```bash
   git init
   git add .
   git commit -m "APP 1933 彩虹版"
   git branch -M main
   git remote add origin https://github.com/你的用戶名/app1933-rainbow.git
   git push -u origin main
   ```
4. GitHub Actions 自動觸發：
   - 自動建置 APK -> Artifacts 下載 `app-debug.apk` (已可用 APK 查巴士)
   - 自動部署官網到 GitHub Pages

### 方法 2: 直接上傳 ZIP 到 GitHub 讓 Actions 解壓 (唔使本地解壓)
1. 喺 GitHub 建一個空 Repo
2. 直接將呢個 ZIP 上傳到 Repo 根目錄 (用網頁 Upload files)
3. Push
4. Actions 入面嘅 `GitHub 解壓 + 建置 APK + 部署網站` workflow 會：
   ```bash
   unzip -o *.zip -d ./
   ```
   自動解壓，再建置 APK + 部署 Pages

### 方法 3: 用 GitHub CLI 一鍵解壓
```bash
gh repo create app1933-rainbow --public
gh repo clone app1933-rainbow
cd app1933-rainbow
unzip ../app1933-github-unzip-ready.zip -d .
git add . && git commit -m "init" && git push
```

## 📁 解壓後結構
```
/
├── index.html              # 主功能版 - 可查巴士 (同 APK 共用)
├── docs/
│   ├── index.html          # GitHub Pages 官網 (同款排版，App1933 介紹)
│   ├── about.html          # App1933 功能介紹版
│   ├── manifest.json
│   └── icons/              # 彩虹巴士全套 icon
├── .github/workflows/
│   ├── build-and-deploy.yml # 解壓 + 建 APK + 部署 Pages
│   └── deploy-pages.yml     # 純部署官網
├── icons/                  # 全套 icon
└── manifest.json
```

## 🚌 功能 (同真 App1933 一樣)
- 一APP睇晒：九巴、龍運
- 預計到站：未來 3 班，倒數更新
- 實時載客量：上層尚餘座位
- 智能搵路線、鄰近路線、收藏、落車提示
- 數據：DATA.GOV.HK 九巴開放數據

## 📱 用 APK 查
- 出嚟嘅 APK WebView 直連 API，無 CORS 問題，真實 ETA
- Icon 已換做你嘅彩虹巴士

Icon 原圖：你的彩虹巴士圖
